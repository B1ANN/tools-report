<h1>007Spam-BOT </h1>
<p><a href="https://github.com/mrwn007/007spam-BOT"><img  style="max-width:100%;"></a>
<a href="https://github.com/mrwn007/007spam-BOT"><img src="https://img.shields.io/badge/Release-Stable-orange.svg" alt="Stage" data-canonical-src="https://img.shields.io/badge/Release-Stable-orange.svg" style="max-width:100%;"></a>
<a href="https://github.com/mrwn007/007spam-BOT"><img src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" alt="Build" data-canonical-src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" style="max-width:100%;"></a></p>
<p><h1>Auto report Instagram accounts ( SPAM BOT ) 😈 </h1>
<br> ⚠️Note! : We don't Accept any responsibility for any illegal usage.</p>

<h2>007spam-BOT</h2>


<img src="https://i.imgur.com/CifoNw5.jpg" data-canonical-src="https://www.youtube.com/watch?v=JX7fg5HrrSE&t=95s" style="max-width:100%;">




<h2>Usage</h2>

<h2>Example</h2>
<p>run the tool with this command<p>
<code>python3 bot.py</code>

<h2>💬 Contact</h2>
<li>You Want Ask About Any Thing Add Me On Discord : @marwan.007#3936</li>
<hr>

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)

```bash
git clone https://github.com/mrwn007/007spam-BOT.git
cd 007spam-BOT
pip install requests
python bot.py
```


## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
pkg install git
pkg install python
git clone https://github.com/mrwn007/007spam-BOT.git
cd 007spam-BOT
python3 -m pip install requests
python3 bot.py
```

## Installation [Windows ](https://wikipedia.org/wiki/Microsoft_Windows)[![alt tag](http://icons.iconarchive.com/icons/tatice/cristal-intense/32/Windows-icon.png)](https://fr.wikipedia.org/wiki/Microsoft_Windows)
```bash
Download python3
Download 007spam-BOT
Extract 007spam-BOT into Desktop
Open CMD and type the following commands:
cd Desktop/007spam-BOT-master/
python -m pip install requests
bot.bat 
```
<h2>Version</h2>
<strong>Current version is 0.0.1</strong>
